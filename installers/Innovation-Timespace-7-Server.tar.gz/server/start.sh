#!/usr/bin/env bash

java -jar packwiz-installer-bootstrap.jar -g -s server https://raw.githubusercontent.com/Kneelawk/Innovation-Timespace-6/main/pack.toml

java -XX:+UseG1GC -Xmx12G -Xms8G -Dsun.rmi.dgc.server.gcInterval=2147483646 -XX:+UnlockExperimentalVMOptions -XX:G1NewSizePercent=20 -XX:G1ReservePercent=20 -XX:MaxGCPauseMillis=50 -XX:G1HeapRegionSize=32M -jar quilt-server-launch.jar nogui

