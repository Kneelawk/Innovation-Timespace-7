# Innovation Timespace 7 Server

This is the Innovation Timespace 7 server.

## Setup Instructions

1. Run `install-quilt.sh` to install QuiltLoader and download the Minecraft server jar.
2. In the `server` directory, run the `start` script. This downloads the mods and starts the server.

The next time you need to start the server, you can just run `start` from the `server` directory.

If you ever need to update the version of QuiltLoader that your server uses, you can re-run `install-quilt.sh` from this directory.
