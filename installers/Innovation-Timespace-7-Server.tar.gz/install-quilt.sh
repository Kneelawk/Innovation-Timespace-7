#!/usr/bin/env bash

java -jar quilt-installer.jar install server 1.20.1 --download-server

